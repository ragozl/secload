import { Precondition } from '@sapphire/framework';

const developers = [
	"659635649640529921", // C🏞️
	"622319114530324491", // Soap
]

class UserPrecondition extends Precondition {
	/**
	 * @param {import('discord.js').Message} message
	 */
	messageRun(message) {
		return this.verify(message.author.id);
	}

	/**
	 * @param {import('discord.js').ChatInputCommandInteraction} interaction
	 */
	chatInputRun(interaction) {
		return this.verify(interaction.user.id);
	}

	/**
	 * @param {import('discord.js').ContextMenuCommandInteraction} interaction
	 */
	contextMenuRun(interaction) {
		return this.verify(interaction.user.id);
	}

	/**
	 * @param {string}
	 */

	verify(userId) {
		return developers.includes(userId)
			? this.ok()
			: this.error({ message: "Only developers can use this command!" })
	}
}


export default UserPrecondition