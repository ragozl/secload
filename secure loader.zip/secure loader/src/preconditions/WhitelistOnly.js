import { Precondition } from '@sapphire/framework';
import fs from "fs"

class UserPrecondition extends Precondition {
    /**
     * @param {import('discord.js').Message} message
     */
    messageRun(message) {
        return this.verify(message.author)
    }

    /**
     * @param {import('discord.js').ChatInputCommandInteraction} interaction
     */
    chatInputRun(interaction) {
        return this.verify(interaction.user)
    }

    /**
     * @param {import('discord.js').ContextMenuCommandInteraction} interaction
     */
    contextMenuRun(interaction) {
        return this.verify(interaction.user)
    }

    async verify(user) {
        return fs.existsSync(`configs/${user.id.toString()}.json`)
            ? this.ok()
            : this.error({ message: "You must be whitelisted to use this command!" })
    }
}

export default UserPrecondition