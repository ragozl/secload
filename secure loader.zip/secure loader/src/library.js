import fs from "fs"
import { encrypt, decrypt } from "./lib/encrypt.js"
import { obfuscate } from "./lib/obfuscate.js"
import { sizeSync } from "./lib/fs-plus.js"
import { debug } from "./lib/debug.js"

function checkWhitelist(userid) {
    if (fs.existsSync(`configs/${userid}.json`)) {
        return true
    }
    return false
}

function checkAdmin(userid) {
    const admins = JSON.parse(fs.readFileSync("data/admins.json"))
    if (admins.includes(userid)) {
        return true
    }
    return false
}

function appendRunLogMessage(owner, robloxuser, scriptname, key) {
    if (!checkWhitelist(owner)) { return }

    const d = new Date();
    const utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    const nd = new Date(utc + (3600000 * -8));
    const date = nd.toLocaleString();

    fs.appendFileSync(`runlogs/${owner}.txt`, `${robloxuser} ran ${scriptname} (${key}) - ${date}\n`)
}

function createSafeRandomString(len) {
    const length = len || 20
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789=_-+";
    let result = "";
    const randomArray = new Uint8Array(length);
    crypto.getRandomValues(randomArray);
    randomArray.forEach((number) => {
        result += chars[number % chars.length];
    });
    return result;
}

function createRandomString(len) {
    const length = len || 20
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789=_-+~()!@#$%^&*:;{}[]|,<>?";
    let result = "";
    const randomArray = new Uint8Array(length);
    crypto.getRandomValues(randomArray);
    randomArray.forEach((number) => {
        result += chars[number % chars.length];
    });
    return result;
}

function clamp(n, min, max) {
    return Math.min(Math.max(n, min), max)
}

function IsStringSafe(str) {
    const regex = /^[a-zA-Z0-9_=\)\(\*\&\^\%\#\@\!\~\|\[\]\<\>\?\-\+]+$/g
    if (str.match(regex)) {
        return true
    }
    return false
}

function GetRobloxUser(id) {
    if (fs.existsSync(`config/${id}.json`)) {
        return JSON.parse(fs.readFileSync(`config/${id}`)).RobloxUser || false
    }
    return false
}

export {
    // scripts
    encrypt,
    decrypt,
    obfuscate,
    GetRobloxUser,
    // more fs 
    sizeSync,
    // internal
    appendRunLogMessage,
    checkWhitelist,
    checkAdmin,
    createSafeRandomString,
    clamp,
    IsStringSafe,
    createRandomString,
    debug
}