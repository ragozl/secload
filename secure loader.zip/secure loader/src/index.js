import { encrypt, decrypt, obfuscate, sizeSync, createRandomString, createSafeRandomString, clamp, IsStringSafe, debug } from "./library.js"
import { configDotenv } from "dotenv"
import Fastify from 'fastify'
import fastifyRateLimit from '@fastify/rate-limit'
import fastifyStatic from '@fastify/static'
import fs from 'fs'
import axios from "axios"
import path from "path"
import client from "./bot.js"
import * as Sentry from "@sentry/node"
import { nodeProfilingIntegration } from "@sentry/profiling-node"

configDotenv({ path: "src/.env" })

const SECURITYCODES = {
    "CheckValidKey": process.env.SECURITYCODE_CHECKVALIDKEY,
    "ChangeValidKey": process.env.SECURITYCODE_CHANGEVALIDKEY,
    "RemoveValidKey": process.env.SECURITYCODE_REMOVEVALIDKEY,
    "AddScript": process.env.SECURITYCODE_ADDSCRIPT,
    "RemoveScript": process.env.SECURITYCODE_REMOVESCRIPT
}

const AES_SECRETS = {
    "DBKEY": process.env.DBENCRYPTION,
    "DBIV": process.env.DBSALT,
    "PRIVATEAES": process.env.PRIVATEAES,
    "PUBLICAES": process.env.PUBLICAES
}

Sentry.init({
    dsn: "https://2e198db5c5280728812831d5f8ecfb81@o4507587651174400.ingest.us.sentry.io/4508164271505408",
    integrations: [
        nodeProfilingIntegration(),
    ],
    tracesSampleRate: 1.0,
    profilesSampleRate: 1.0,
});

const fastify = Fastify({
    logger: {
        serializers: {
            res(res) {
                debug.log(`[api] [response]: Status ${res.statusCode}`, '[api] [output]')
                return `Status ${res.statusCode}`
            },
            req(req) {
                debug.log(`[api] [request]: [${req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip}] :: ${req.method} ${req.url} <with> ${req.parameters || "[no params]"}`)
                return `[${req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip}] :: ${req.method} ${req.url} <with> ${req.parameters || "[no params]"}`
            }
        }
    }
})

function pushTrustedIPs(ip) {
    const trustedIPs = JSON.parse(fs.readFileSync("data/trustedIPs.json"))
    trustedIPs.push(ip)
    fs.writeFileSync("data/trustedIPs.json", JSON.stringify(trustedIPs, null, 4))
}

function getTrustedIPs() {
    return JSON.parse(fs.readFileSync("data/trustedIPs.json"))
}

await fastify.register(fastifyRateLimit, {
    global: true,
    max: async (req, key) => {
        if (getTrustedIPs().includes(key)) return 900
        const info = await axios.get(`http://ip-api.com/json/${key}?fields=28160`).data
        if (!info) return 300
        if (info.status !== "success") return 300
        if (
            (info.as === "AS22697 Roblox" || info.as === "AS11281 Roblox")
            && info.isp == "Roblox"
            && info.org == "Roblox"
        ) {
            pushTrustedIPs(key)
            return 900
        }
        return 300
    },
    timeWindow: "1 minute",
    keyGenerator: (req) => req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip
})

const trustedHosts = ["secload.scriptlang.com", "secload.ocbwoy3.dev"]
await fastify.addHook("preHandler", async (request, res) => { // trusted host middleware & anti vpn/banned ips
    const ip = request.headers["cf-connecting-ip"] || request.headers["x-forwarded-for"] || request.ip
    const v4 = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/g
    const v6 = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/g

    if (!trustedHosts.includes(request.hostname) || !ip || (!ip.match(v4) && !ip.match(v6))) {
        debug.error(`blocked an ip (${ip})`)
        const stream = fs.createReadStream("html/invalidhost.html")
        return res
            .status(401)
            .type('text/html')
            .send(stream)
    }

    const ALLOWEDIPS = JSON.parse(fs.readFileSync("data/trustedIPs.json"))
    const BANNEDIPS = JSON.parse(fs.readFileSync("data/bannedIPs.json"))
    const BANNEDASNS = JSON.parse(fs.readFileSync("data/bannedASNs.json"))
    const BANNEDISPS = JSON.parse(fs.readFileSync("data/bannedISPs.json"))
    const BANNEDORGS = JSON.parse(fs.readFileSync("data/bannedOrgs.json"))

    const ipdata = await axios.get(`http://ip-api.com/json/${ip}?fields=status,message,proxy,org,isp,as,query,hosting`)
    const ipcheck = ipdata.data

    if (!ALLOWEDIPS.includes(ip) && (BANNEDIPS.includes(ip) || BANNEDASNS.includes(ipcheck.as) || BANNEDISPS.includes(ipcheck.isp) || BANNEDORGS.includes(ipcheck.org) || ipcheck["proxy"] == true && ipcheck["hosting"] == false)) {
        debug.error(`blocked an ip (${ip})`)
        const stream = fs.createReadStream("html/banned.html")
        return res
            .status(401)
            .type('text/html')
            .send(stream)
    }
})

async function checkIsRoblox(request, res) {
    const ip = request.headers["cf-connecting-ip"] || request.headers["x-forwarded-for"] || request.ip
    if (!getTrustedIPs().includes(ip)) {
        pushTrustedIPs(ip)
        const info = await axios.get(`http://ip-api.com/json/${ip}?fields=28160`).data

        if (info.status !== "success") { logger.error("Client must have a public IP"); return res.status(401).send("Client must have a public IP") }
        if (!((info.as === "AS22697 Roblox" || info.as === "AS11281 Roblox") && info.isp == "Roblox" && info.org == "Roblox")) {
            debug.error(`an ip tried to access a ROBLOX only endpoint (${ip})`)
            return res.status(401).send("Client must be from ROBLOX")
        }
    }
}

fastify.register((instance, opts, next) => {
    instance.register(fastifyStatic, {
        root: path.join("/home/equsjd/source/SecLoadJS", 'static'),
        prefix: '/static/'
    })
    next()
})

fastify.register((instance, opts, next) => {
    instance.register(fastifyStatic, {
        root: path.join("/home/equsjd/source/SecLoadJS", 'deps'),
        prefix: '/deps/'
    })
    next()
})

fastify.get("/", async (request, res) => {
    const stream = fs.createReadStream("html/root.html")
    return res
        .type('text/html')
        .send(stream)
})

fastify.get("/license", async (request, res) => {
    const stream = fs.createReadStream("html/license.html")
    return res
        .type('text/html')
        .send(stream)
})

fastify.get("/secload/CheckIsRoblox", async (request, res) => {
    return res.send("hi")
})

fastify.get("/secload/IDs", { preHandler: checkIsRoblox }, async (request, res) => {
    const stream = fs.createReadStream("html/root.html")
    return res
        .type('text/html')
        .send(stream)
})

fastify.get("/anticheat/AntiBackdoor", { preHandler: checkIsRoblox }, async (request, res) => {
    const stream = fs.createReadStream("src/lua/backdoor.lua")
    return res
        .type('text/html')
        .send(stream)
})

fastify.get("/HTTPLoader", { preHandler: checkIsRoblox }, async (request, res) => {
    const stream = fs.createReadStream("src/lua/loader.lua")
    return res
        .type('text/plain')
        .send(stream)
})

fastify.get("/Runner", { preHandler: checkIsRoblox }, async (request, res) => {
    const stream = fs.createReadStream("src/lua/runner.lua")
    return res
        .type('text/plain')
        .send(stream)
})

fastify.post("/secload/CheckValidKey", {
    schema: {
        body: {
            type: "object",
            properties: {
                SecurityCode: { type: "string" },
                ValidKey: { type: "string" },
                RobloxUser: { type: "string" },
            },
            required: ["SecurityCode", "ValidKey", "RobloxUser"]
        }
    },
    preHandler: checkIsRoblox
}, async (request, res) => {
    const { SecurityCode, ValidKey, RobloxUser } = request.body

    if (!SecurityCode || SecurityCode != SECURITYCODES.RemoveValidKey) { return res.status(400).send("Invalid security code") }
    if (!ValidKey || !fs.existsSync(`keys/${ValidKey}.json`) || !IsStringSafe(ValidKey)) { return res.status(400).send("Key does not exist") }

    const { Owner, Script, IV, Perm, OwnerUser } = JSON.parse(fs.readFileSync(`keys/${ValidKey}.json`))
    const ScriptLocation = `scripts/${Owner}/${Script}`

    if (OwnerUser != "" && OwnerUser != RobloxUser) { return res.status(400).send("User is not whitelisted to run this script.") }
    if (!fs.existsSync(ScriptLocation) || !fs.existsSync(`${ScriptLocation}/${Script}.lua`)) { return res.status(400).send("Script does not exist") }

    const ScriptSource = fs.readFileSync(`${ScriptLocation}/${Script}.lua`)
    if (!Perm) {
        fs.unlinkSync(`keys/${ValidKey}.json`)
    }

    const source = decrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, ScriptSource)
    const script = `-- thanks Athena\n---------------------------------------------------------------------------------------\n${source}`
    const encrypted = encrypt(AES_SECRETS.PRIVATEAES, IV, script)

    debug.log(`sending source of ${Script} from ${Owner}`)

    return res
        .type('text/plain')
        .send(encrypted)
})

fastify.post("/secload/userapi/ListUserScripts", {
    schema: {
        body: {
            type: "object",
            properties: {
                UserApiKey: { type: "string" }
            },
            required: ["UserApiKey"]
        }
    }
}, async (request, res) => {
    const { UserApiKey } = request.body
    if (!UserApiKey || !fs.existsSync(`userapikeys/${UserApiKey}.json`) || !IsStringSafe(UserApiKey)) { return res.status(400).send("User API key does not exist") }

    const { Owner } = JSON.parse(fs.readFileSync(`userapikeys/${UserApiKey}.json`))
    const scripts = []
    const list = fs.readdirSync(`scripts/${Owner}`)
    for (const script of list) {
        if (script.endsWith(".lua")) {
            scripts.push(script.slice(0, script.length - 4))
        }
    }

    return res
        .type("application/json")
        .send(scripts)
})

fastify.post("/secload/userapi/RemoveUserScript", {
    schema: {
        body: {
            type: "object",
            properties: {
                UserApiKey: { type: "string" },
                ScriptName: { type: "string" }
            },
            required: ["UserApiKey", "ScriptName"]
        }
    }
}, async (request, res) => {
    const { UserApiKey, ScriptName } = request.body
    if (!UserApiKey || !fs.existsSync(`userapikeys/${UserApiKey}.json`) || !IsStringSafe(UserApiKey)) { return res.status(400).send("User API key does not exist.") }

    const { Owner, IsItReadOnly } = JSON.parse(fs.readFileSync(`userapikeys/${UserApiKey}.json`))
    if (IsItReadOnly) { return res.status(400).send("User API key is read only.") }

    if (!fs.existsSync(`scripts/${Owner}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("Script does not exist.") }
    fs.rmdirSync(`scripts/${Owner}/${ScriptName}`)

    return res.send("Success")
})

fastify.post("/secload/userapi/AddUserScript", {
    schema: {
        body: {
            type: "object",
            properties: {
                UserApiKey: { type: "string" },
                ScriptName: { type: "string" },
                Source: { type: "string" },
                Obfuscated: { type: "boolean" }
            },
            required: ["UserApiKey", "ScriptName", "Source", "Obfuscated"]
        }
    }
}, async (request, res) => {
    const { UserApiKey, ScriptName, Source, Obfuscated } = request.body
    if (!UserApiKey || !fs.existsSync(`userapikeys/${UserApiKey}.json`) || !IsStringSafe(UserApiKey)) { return res.status(400).send("User API key does not exist.") }

    const { Owner, IsItReadOnly } = JSON.parse(fs.readFileSync(`userapikeys/${UserApiKey}.json`))
    if (IsItReadOnly) { return res.status(400).send("User API key is read only.") }

    if (Source.length > 1000000) { return res.status(400).send("Script file exceeds 1 MB") }
    if (sizeSync(`scripts/${Owner}`) >= 15000000) { return res.status(400).send("User list exceeds 15 MB") }
    if (fs.existsSync(`scripts/${Owner}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("A script already exists with the same name.") }

    fs.mkdir(`scripts/${Owner}/${ScriptName}`)
    fs.writeFileSync(`scripts/${Owner}/${ScriptName}/{ScriptName}.json`, `
{
    "${ScriptName}.lua": {
        "Owner": "${Owner}",
        "Whitelisted": {
            "${Owner}": true        
        },
        "Sharable": true,
        "Viewable": true
    }
}
`)
    let source
    if (Obfuscated) {
        source = await obfuscate(Source)
    }
    else {
        source = Source
    }
    const enc = encrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, source)
    fs.writeFileSync(`scripts/${Owner}/${ScriptName}/${ScriptName}.lua`, enc)

    return res.send("Success")
})

fastify.post("/secload/userapi/ReadUserScript", {
    schema: {
        body: {
            type: "object",
            properties: {
                UserApiKey: { type: "string" },
                ScriptName: { type: "string" }
            },
            required: ["UserApiKey", "ScriptName"]
        }
    }
}, async (request, res) => {
    const { UserApiKey, ScriptName } = request.body
    if (!UserApiKey || !fs.existsSync(`userapikeys/${UserApiKey}.json`) || !IsStringSafe(UserApiKey)) { return res.status(400).send("User API key does not exist") }

    const { Owner } = JSON.parse(fs.readFileSync(`userapikeys/${UserApiKey}.json`))
    if (!fs.existsSync(`scripts/${Owner}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("Script does not exist.") }

    const { Viewable } = JSON.parse(fs.readFileSync(`scripts/${Owner}/${ScriptName}/${ScriptName}.json`))[`${ScriptName}.lua`]
    if (!Viewable || !IsStringSafe(ScriptName)) { return res.status(400).send("You cannot view this script.") }

    const enc = fs.readFileSync(`scripts/${Owner}/${ScriptName}/${ScriptName}.lua`)
    return res
        .type("text/plain")
        .send(decrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, enc))
})

fastify.post("/secload/userapi/ShareUserScript", {
    schema: {
        body: {
            type: "object",
            properties: {
                UserApiKey: { type: "string" },
                ScriptName: { type: "string" },
                UserId: { type: "number" },
                Sharable: { type: "boolean" },
                Viewable: { type: "boolean" }
            },
            required: ["UserApiKey", "ScriptName", "UserId", "Sharable", "Viewable"]
        }
    }
}, async (request, res) => {
    let { UserApiKey, ScriptName, UserId, Sharable, Viewable } = request.body
    if (!UserApiKey || !fs.existsSync(`userapikeys/${UserApiKey}.json`) || !IsStringSafe(UserApiKey)) { return res.status(400).send("User API key does not exist") }

    const { Owner, IsItReadOnly } = JSON.parse(fs.readFileSync(`userapikeys/${UserApiKey}.json`))
    if (IsItReadOnly) { return res.status(400).send("User API key is read only.") }

    if (!fs.existsSync(`scripts/${Owner}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("Script does not exist.") }
    if (!fs.existsSync(`scripts/${UserId}`) || !IsStringSafe(UserId)) { return res.status(400).send("User does not exist.") }
    if (fs.existsSync(`scripts/${UserId}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("User already has a script with the same name.") }

    if (sizeSync(`scripts/${UserId}`) >= 15000000) { return res.status(400).send("User list exceeds 15 MB") }

    const ScriptData = JSON.parse(fs.readFileSync(`scripts/${Owner}/${ScriptName}/${ScriptName}.json`))
    if (ScriptData.Sharable == false) { return res.status(400).send("You cannot share this script.") }
    Viewable = ScriptData.Viewable

    fs.mkdirSync(`scripts/${UserId}/${ScriptName}`)
    fs.copyFileSync(`scripts/${Owner}/${ScriptName}.lua`, `scripts/${UserId}/${ScriptName}`)

    fs.writeFileSync(`scripts/${UserId}/${ScriptName}/${ScriptName}.json`, `
{
    ${ScriptName}.lua: {
        "Owner": "${Owner}",
        "Whitelisted": {
            "${UserId}": true
        },
        "Sharable": ${Sharable},
        "Viewable": ${Viewable},
        "AutoUpdate": true,
        "ShareUpdate": [
            ${Owner}
        ]
    }
}        
`)

    const OwnerData = JSON.parse(fs.readFileSync(`scripts/${Owner}/${ScriptName}/${ScriptName}.json`))
    if (!OwnerData.AutoUpdate && !OwnerData.ShareUpdate) {
        OwnerData.AutoUpdate = Owner
        OwnerData.ShareUpdate = [
            UserId
        ]
    }
    else {
        OwnerData.ShareUpdate.push(UserId)
    }
    fs.writeFileSync(JSON.stringify(OwnerData, null, 4))

    return res.send("Success")
})

fastify.post("/secload/publicapi/GenerateAPIKey", {
    schema: {
        body: {
            type: "object",
            properties: {
                Length: { type: "number" }
            },
            required: ["Length"]
        }
    }
}, async (request, res) => {
    const { Length } = request.body
    const ip = request.headers["cf-connecting-ip"] || request.headers["x-forwarded-for"] || request.ip

    const keylen = clamp(Length, 25, 255) // for security and prevent too long keys
    let newkey = createSafeRandomString(keylen)
    const apikeysgenerated = JSON.parse(fs.readFileSync("data/apiKeysGenerated.json"))

    while (fs.existsSync(`publicapi/${newkey}`)) { // prevent key conflicts
        newkey = createSafeRandomString(keylen)
    }

    if (apikeysgenerated[ip]) {
        if (apikeysgenerated[ip].length >= 3) {
            return res.status(400).send("User has too many API keys. # of keys >= 3")
        }
        else {
            apikeysgenerated[ip].push(newkey)
        }
    }

    fs.writeFileSync(JSON.stringify(apikeysgenerated, null, 4))
    fs.mkdirSync(`publicapi/${newkey}`)

    return res.type("text/plain").send(newkey)
})

fastify.post("/secload/publicapi/RemoveAPIKey", {
    schema: {
        body: {
            type: "object",
            properties: {
                Key: { type: "string" }
            },
            required: ["Key"]
        }
    }
}, async (request, res) => {
    const { Key } = request.body
    const ip = request.headers["cf-connecting-ip"] || request.headers["x-forwarded-for"] || request.ip

    if (!fs.existsSync(`publicapi/${Key}`) || !IsStringSafe(Key)) { return res.status(400).send("API Key does not exist") }
    const apikeysgenerated = JSON.parse(fs.readFileSync("data/apiKeysGenerated.json"))

    if (apikeysgenerated[ip] && apikeysgenerated[ip].indexOf(Key)) {
        const idx = apikeysgenerated[ip].indexOf(Key)
        apikeysgenerated[ip].splice(idx)
    }

    fs.writeFileSync(JSON.stringify(apikeysgenerated, null, 4))
    fs.rmdirSync(`publicapi/${Key}`)

    return res.send("Success")
})

fastify.post("/secload/publicapi/CreateScript", {
    schema: {
        body: {
            type: "object",
            properties: {
                Key: { type: "string" },
                ScriptName: { type: "string" },
                Source: { type: "string" },
                Obfuscated: { type: "boolean" }
            },
            required: ["Key", "ScriptName", "Source", "Obfuscated"]
        }
    }
}, async (request, res) => {
    const { Key, ScriptName, Source, Obfuscated } = request.body

    if (!fs.existsSync(`publicapi/${Key}`) || !IsStringSafe(Key)) { return res.status(400).send("API Key does not exist") }
    if (Source.length > 350000) { return res.status(400).send("Script file exceeds 350 KB of size (350,000 characters)") }
    if (fs.existsSync(`publicapi/${Key}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("Script already exists with the same name") }
    if (sizeSync(`publicapi/${Key}`) / 1e+6 >= 5) { return res.status(400).send("API script list exceeds 5 MB of storage") }

    let source
    if (Obfuscated) {
        const enc = encrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, Obfuscated)
        fs.writeFileSync(`publicapi/${Key}/${ScriptName}/${ScriptName}_unobfuscated.lua`, enc)

        source = await obfuscate(Source)
    }
    else {
        source = Source
    }

    const enc = encrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, source)
    fs.writeFileSync(`publicapi/${Key}/${ScriptName}/${ScriptName}.lua`, enc)

    return res.send("Success")
})

fastify.post("/secload/publicapi/RemoveScript", {
    schema: {
        body: {
            type: "object",
            properties: {
                Key: { type: "string" },
                ScriptName: { type: "string" },
            },
            required: ["Key", "ScriptName"]
        }
    }
}, async (request, res) => {
    const { Key, ScriptName } = request.body

    if (!fs.existsSync(`publicapi/${Key}`) || !IsStringSafe(Key)) { return res.status(400).send("API Key does not exist") }
    if (!fs.existsSync(`publicapi/${Key}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("Script does not exist") }

    fs.rmSync(`publicapi/${Key}/${ScriptName}`)

    return res.send("Success")
})

fastify.post("/secload/publicapi/OverwriteScript", {
    schema: {
        body: {
            type: "object",
            properties: {
                Key: { type: "string" },
                ScriptName: { type: "string" },
                Source: { type: "string" },
                Obfuscated: { type: "boolean" }
            },
            required: ["Key", "ScriptName", "Source", "Obfuscated"]
        }
    }
}, async (request, res) => {
    const { Key, ScriptName, Source, Obfuscated } = request.body

    if (!fs.existsSync(`publicapi/${Key}`) || !IsStringSafe(Key)) { return res.status(400).send("API Key does not exist") }
    if (Source.length > 350000) { return res.status(400).send("Script file exceeds 350 KB of size (350,000 characters)") }
    if (!fs.existsSync(`publicapi/${Key}/${ScriptName}`) || !IsStringSafe(ScriptName)) { return res.status(400).send("Script doesnt exist") }

    let source
    if (Obfuscated) {
        const enc = encrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, Obfuscated)
        fs.writeFileSync(`publicapi/${Key}/${ScriptName}/${ScriptName}_unobfuscated.lua`, enc)

        source = await obfuscate(Source)
    }
    else {
        source = Source
    }

    const enc = encrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, source)
    fs.writeFileSync(`publicapi/${Key}/${ScriptName}/${ScriptName}.lua`, enc)

    return res.send("Success")
})

fastify.post("/secload/publicapi/ListScripts", {
    schema: {
        body: {
            type: "object",
            properties: {
                Key: { type: "string" }
            },
            required: ["Key"]
        }
    }
}, async (request, res) => {
    const { Key } = request.body

    if (!fs.existsSync(`publicapi/${Key}`) || !IsStringSafe(Key)) { return res.status(400).send("API Key does not exist") }

    const scripts = []
    const list = fs.readdirSync(`scripts/${Owner}`)
    for (const script of list) {
        if (script.endsWith(".lua") && !script.endsWith("_unobfuscated.lua")) {
            scripts.push(script.slice(0, script.length - 4))
        }
    }

    return res
        .type("application/json")
        .send(scripts)
})

fastify.post("/secload/publicapi/CheckValidKey", {
    schema: {
        body: {
            type: "object",
            properties: {
                SecurityCode: { type: "string" },
                ValidKey: { type: "string" }
            },
            required: ["SecurityCode", "ValidKey"]
        }
    },
    preHandler: checkIsRoblox
}, async (request, res) => {
    const { SecurityCode, ValidKey } = request.body

    if (!SecurityCode || SecurityCode != SECURITYCODES.RemoveValidKey) { return res.status(400).send("Invalid security code") }
    if (!ValidKey || !fs.existsSync(`publicapikeys/${ValidKey}.json`) || !IsStringSafe(ValidKey)) { return res.status(400).send("Key does not exist") }

    const { Owner, Script, IV } = JSON.parse(fs.readFileSync(`publicapikeys/${ValidKey}.json`))
    const ScriptLocation = `publicapi/${Owner}`

    if (!fs.existsSync(ScriptLocation) || !fs.existsSync(`${ScriptLocation}/${Script}.lua`)) { return res.status(400).send("Script does not exist") }

    const ScriptSource = fs.readFileSync(`${ScriptLocation}/${Script}.lua`)
    if (Owner != "fuWqhhsiR6j5aY5Px8i2UqXXcBw-3Tsc1CLR6xyy9t-Ylf38EnaU8HPrZ-Sett5TJYWTPd0GKQ1fVnN57IKk8abfydV9KI5ktk1W" && Script != "karma") {
        fs.unlinkSync(`keys/${ValidKey}.json`)
    }

    const source = decrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, ScriptSource)
    const script = `-- thanks Athena\n---------------------------------------------------------------------------------------\n${source}`
    const encrypted = encrypt(AES_SECRETS.PUBLICAES, IV, script)

    debug.log(`sending source of ${Script} from ${Owner}`)

    return res
        .type('text/plain')
        .send(encrypted)
})

fastify.post("/secload/publicapi/GenerateKey", {
    schema: {
        body: {
            type: "object",
            properties: {
                Key: { type: "string" },
                Script: { type: "string" },
                Username: { type: "string" },
                Time: { type: "number" }
            },
            required: ["Key", "Script", "Username", "Time"]
        }
    },
    preHandler: checkIsRoblox
}, async (request, res) => {
    const { Key, Script, Username, Time } = request.body

    let MinuteExpire = clamp(Time, 1, 60) * 60 * 1000

    if (!fs.existsSync(`publicapi/${Key}`) || !IsStringSafe(Key)) { return res.status(400).send("API Key does not exist") }
    if (!fs.existsSync(`publicapi/${Key}/${Script}.lua`) || !IsStringSafe(Script)) { return res.status(400).send("Script does not exist") }

    const randomkey = createRandomString(64)
    const ivkey = createRandomString(16)

    let keydata

    if (Key == "fuWqhhsiR6j5aY5Px8i2UqXXcBw-3Tsc1CLR6xyy9t-Ylf38EnaU8HPrZ-Sett5TJYWTPd0GKQ1fVnN57IKk8abfydV9KI5ktk1W" && Script == "karma") {
        keydata = {
            "Owner": Key,
            "Key": randomkey,
            "Script": Script,
            "IV": ivkey,
            "Karma": {
                "Owner": Username
            }
        }
    }
    else {
        keydata = {
            "Owner": Key,
            "Key": randomkey,
            "Script": Script,
            "IV": ivkey
        }
    }

    fs.writeFileSync(`publicapikeys/${randomkey}.json`, JSON.stringify(keydata, null, 4))
    setTimeout(() => {
        fs.rmSync(`publicapikeys/${randomkey}.json`)
    }, MinuteExpire)

    return res
        .type('text/plain')
        .send(`require(17890624224)(${randomkey}, ${ivkey}, owner and owner.Name or "${Username || "username"}", true)`)
})

fastify.post("/secload/publicapi/GetScriptSource", {
    schema: {
        body: {
            type: "object",
            properties: {
                Key: { type: "string" },
                Script: { type: "string" }
            },
            required: ["Key", "Script"]
        }
    },
    preHandler: checkIsRoblox
}, async (request, res) => {
    const { Key, Script } = request.body

    if (!fs.existsSync(`publicapi/${Key}`) || !IsStringSafe(Key)) { return res.status(400).send("API Key does not exist") }
    if (!fs.existsSync(`publicapi/${Key}/${Script}.lua`) || !IsStringSafe(Script)) { return res.status(400).send("Script does not exist") }

    const ScriptSource = fs.readFileSync(`publicapi/${Key}/${Script}.lua`)
    const source = decrypt(AES_SECRETS.DBKEY, AES_SECRETS.DBIV, ScriptSource)

    return res
        .type('text/plain')
        .send(source)
})

const theport = 2500
const start = async () => {
    await fastify.listen({ port: theport, host: "0.0.0.0" })
    client.login(process.env.TOKEN)
    debug.log("[init]: Listening on " + theport)
}
start()