import { debug } from "./library.js"

debug.log("this is a test")
debug.log("hello", "world")
debug.error("hi")