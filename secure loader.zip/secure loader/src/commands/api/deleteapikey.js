import { Command } from '@sapphire/framework';
import fs from "fs"

class AnonymousCommand extends Command {
    constructor(context, options) {
        super(context, {
            ...options,
            aliases: ["removeapikey"],
            preconditions: ["WhitelistOnly"]
        });
    }

    /**
     * @param {import('discord.js').Message} message
     */
    async messageRun(message) {
        const id = message.author.id
        if (!fs.existsSync(`scripts/${id}/UserApiKey.json`)) { return await message.reply("You don't have a user API key generated.") }

        const { TheApiKey } = JSON.parse(fs.readFileSync(`scripts/${id}/UserApiKey.json`))
        fs.rmSync(`scripts/${id}/UserApiKey.json`)
        fs.rmSync(`userapikeys/${TheApiKey}.json`)

        return await message.reply("Removed your API key.")
    }
}

export default AnonymousCommand