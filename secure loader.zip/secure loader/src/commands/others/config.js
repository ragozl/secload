import { Command } from '@sapphire/framework';
import fs from "fs"

class AnonymousCommand extends Command {
    constructor(context, options) {
        super(context, {
            ...options,
            aliases: ["newscript", "createscript"],
            preconditions: ["WhitelistOnly"]
        });
    }

    /**
     * @param {import('discord.js').Message} message
     */
    async messageRun(message, args) {
        const author = message.author
        const type = await args.pick('string').catch(() => {
            return message.reply("You must include a <type>. Example: ;config [username] equsjd1")
        })
        const arg = await args.rest('string').catch(() => {
            if (typee.toLowerCase() != "get") {
                return message.reply("You must include a <value>. Example: ;config username [equsjd1]")
            }
        })
        const typee = type.toLowerCase()

        if (typee == "username") {
            const usernameregex = /^[a-zA-Z0-9_]*$/g
            if (arg.length < 3 || args.length > 20) { return message.reply("Username must be 3-20 characters.") }
            if (!arg.match(usernameregex)) { return message.reply("Username must be alphanumeric and/or have an underscore.") }
            const configdata = JSON.parse(fs.readFileSync(`configs/${author.id}.json`))
            configdata["RobloxUser"] = arg
            fs.writeFileSync(JSON.stringify(configdata, null, 4))
            return message.reply(`Set your username to '${arg}'`)
        }
        else if (typee == "get") {
            return message.reply({
                files: [`configs/${author.id}.json`]
            })
        }
        else {
            return message.reply("Invalid <type>. Must be 'username' or 'get'")
        }
    }
}

export default AnonymousCommand