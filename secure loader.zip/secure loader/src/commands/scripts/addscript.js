import { Command } from '@sapphire/framework';
import { encrypt, obfuscate, sizeSync, IsStringSafe } from "../../library.js"
import fs from "fs"
import axios from "axios"
import { config } from "dotenv"
import path from "path"
config({ path: "../.env" })

class AnonymousCommand extends Command {
    constructor(context, options) {
        super(context, {
            ...options,
            aliases: ["newscript", "createscript"],
            preconditions: ["WhitelistOnly"]
        });
    }

    /**
     * @param {import('discord.js').Message} message
     */
    async messageRun(message, args) {
        const scriptname = await args.pick('string').catch(() => {
            return message.reply("You must include a <scriptname>. Usage: ;newscript scriptname <file>")
        })
        const obfuscated = await args.pick('boolean').catch(() => false)
        const scriptpath = `scripts/${message.author.id}/${scriptname}`
        const loading = await message.reply(`Attempting to create ${scriptname}... <a:loading:1294764625774247996>`)

        if (fs.existsSync(scriptpath) || !IsStringSafe(scriptname)) { return loading.edit({ content: "You already have a script called " + scriptname }) }

        const attachment = message.attachments.first();
        const url = attachment ? attachment.url : null;
        if (!url) { return loading.edit("No attachment found") }

        const FileName = path.basename(url)
        const split1 = FileName.split(".")[1]
        const fileextension = split1.split("?")[0]

        const file = await axios.get(url)
        const filesource = file.data

        if (!fileextension.includes("txt") && !fileextension.includes("lua")) { return loading.edit("Attachment must be a .txt or .lua file") }
        if (sizeSync("scripts/" + message.author.id) > 15000000) { return loading.edit("User has too much scripts saved. Max of 15 MB") }
        if (attachment.size > 1000000) { return loading.edit("File is too large. Max of 1 MB") }
        var scriptsource
        if (obfuscated == true) {
            scriptsource = await obfuscate(filesource, loading)
        }
        else {
            scriptsource = filesource
        }

        const encrypted = encrypt(process.env.DBENCRYPTION, process.env.DBSALT, scriptsource)
        const sourceencrypted = encrypt(process.env.DBENCRYPTION, process.env.DBSALT, filesource)
        fs.mkdirSync(scriptpath)

        fs.writeFileSync(`${scriptpath}/unobfuscated.lua`, sourceencrypted)
        fs.writeFileSync(`${scriptpath}/${scriptname}.lua`, encrypted)
        fs.writeFileSync(`${scriptpath}/${scriptname}.json`, `{
    "${scriptname}.lua": {
        "Owner": ${message.author.id},
        "Whitelisted": {
            "${message.author.id}": true
        },
        "Sharable": true,
        "Viewable": true
    }
}`)

        return loading.edit("Created " + scriptname + " :white_check_mark:")
    }
}

export default AnonymousCommand