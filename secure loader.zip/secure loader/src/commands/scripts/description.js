import { Command } from '@sapphire/framework'
import { IsStringSafe } from "../../library.js"
import path from 'path'
import fs from "fs"

class AnonymousCommand extends Command {
    constructor(context, options) {
        super(context, {
            ...options,
            aliases: ["desc"],
            preconditions: ["WhitelistOnly"]
        });
    }

    /**
     * @param {import('discord.js').Message} message
     */
    async messageRun(message, args) {
        const id = message.author.id
        const type = await args.pick("string").catch(() => "")
        const scriptname = await args.rest('string').catch(() => "")

        if (!fs.existsSync(`scripts/${id}/${scriptname}`) || !IsStringSafe(scriptname)) { return message.reply("Script does not exist.") }

        switch (type.toLowerCase()) {
            case "get":
                if (!fs.existsSync(`scripts/${id}/${scriptname}/${scriptname}.txt`)) { return message.reply("Script does not have a description") }
                return message.reply({
                    files: [
                        `scripts/${id}/${scriptname}/${scriptname}.txt`
                    ]
                })
            case "set":
                const attachment = message.attachments.first();
                const url = attachment ? attachment.url : null;
                const FileName = path.basename(url)
                const split1 = FileName.split(".")[1]
                const fileextension = split1.split("?")[0]
                const filesource = (await axios.get(url)).data

                if (!url) { return message.reply("Attachment not found.") }
                if (!fileextension.includes("txt")) { return message.reply("Attachment must be a .txt file") }

                fs.writeFileSync(`scripts/${id}/${scriptname}/${scriptname}.txt`, filesource)
                return message.reply(`Set description for '${scriptname}'`)
            default:
                return message.reply("Invalid operation. Type must be 'set' or 'get'.")
        }
    }
}

export default AnonymousCommand