import { Command } from '@sapphire/framework';
import { IsStringSafe, decrypt } from "../../library.js"
import fs from "fs"
import { config } from "dotenv"
config({ path: "../.env" })

class AnonymousCommand extends Command {
    constructor(context, options) {
        super(context, {
            ...options,
            aliases: ["getsource"],
            preconditions: ["WhitelistOnly"]
        });
    }

    /**
     * @param {import('discord.js').Message} message
     */
    async messageRun(message, args) {
        const scriptname = await args.pick('string').catch(() => {
            return message.reply("You must include a <scriptname>. Usage: ;newscript scriptname <file>")
        })

        if (!fs.existsSync(`scripts/${message.author.id}/${scriptname}`) || !IsStringSafe(scriptname)) { return message.reply("Script does not exist.") }
        const config = JSON.parse(fs.readFileSync(`scripts/${message.author.id}/${scriptname}/${scriptname}.json`))
        if (config["Viewable"] != null && config["Viewable"] == false) { message.reply("You cannot view this script.") }

        let source
        if (fs.existsSync(`scripts/${message.author.id}/${scriptname}/unobfuscated.lua`)) {
            source = fs.readFileSync(`scripts/${message.author.id}/${scriptname}/unobfuscated.lua`)
        }
        else {
            source = fs.readFileSync(`scripts/${message.author.id}/${scriptname}/${scriptname}.lua`)
        }

        const decrypted = decrypt(process.env.DBENCRYPTION, process.env.DBSALT, source)
        fs.writeFileSync(decrypted, `pending_source/${message.author.id}_${scriptname}.lua`)

        setInterval(() => {
            if (fs.existsSync(`pending_source/${message.author.id}_${scriptname}.lua`)) {
                fs.rmSync(`pending_source/${message.author.id}_${scriptname}.lua`)
            }
        }, 10000)

        if (fs.existsSync(`pending_source/${message.author.id}_${scriptname}.lua`)) {
            return message.reply({
                files: [
                    `pending_source/${message.author.id}_${scriptname}.lua`
                ]
            })
        }
        else {
            return message.reply("Failed to get source.")
        }
    }
}

export default AnonymousCommand