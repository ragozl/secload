import { Command } from '@sapphire/framework';
import { IsStringSafe } from '../../library.js';
import fs from "fs"

class AnonymousCommand extends Command {
    constructor(context, options) {
        super(context, {
            ...options,
            aliases: ["expirekey", "removekey"],
            preconditions: ["WhitelistOnly"]
        });
    }

    /**
     * @param {import('discord.js').Message} message
     */
    async messageRun(message, args) {
        const id = message.author.id
        const key = await args.rest('string').catch(() => "")

        const keyy = key.toLowerCase()
        if (keyy == "all") {
            const keys = []
            const list = fs.readdirSync(`keys`)
            for (const kee of list) {
                if (kee.endsWith(".json") && JSON.parse(fs.readFileSync(`keys/${kee}`))["Owner"] == id.toString()) {
                    keys.push(kee)
                }
            }
            const msg = await message.reply("Expiring all keys... <a:loading:1294764625774247996>")
            for (const kee of keys) {
                if (fs.existsSync(`keys/${kee}`)) {
                    fs.rmSync(`keys/${kee}`)
                }
                msg.edit(`Expiring key: ${kee} <a:loading:1294764625774247996>`)
            }
            return msg.edit("Successfully cleared all keys. :white_check_mark:")
        }
        else {
            if (!fs.existsSync(`key/${key}.json`) || !IsStringSafe(key)) { return message.reply("Key does not exist.") }
            const { Owner } = JSON.parse(fs.readFileSync(`key/${key}.json`))
            if (Owner != id.toString()) { return message.reply("You cannot expire this key.") }

            fs.rmSync(`key/${key}.json`)
            return message.reply(`Expired key: ${key} :white_check_mark:`)
        }
    }
}

export default AnonymousCommand