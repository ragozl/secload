import { Command } from '@sapphire/framework';
import { IsStringSafe, clamp, GetRobloxUser, createRandomString } from '../../library.js';
import fs from "fs"

class AnonymousCommand extends Command {
    constructor(context, options) {
        super(context, {
            ...options,
            aliases: ["newkey", "generatekey"],
            preconditions: ["WhitelistOnly"]
        });
    }

    /**
     * @param {import('discord.js').Message} message
     */
    async messageRun(message, args) {
        const id = message.author.id
        const scriptname = await args.pick('string').catch(() => "")
        const time = await args.pick('number').catch(() => 5)

        const perm = time <= 0
        let t
        if (perm) {
            t = "perm"
        }
        else {
            t = clamp(time, 1, 60)
        }

        const randomkey = createRandomString(64)
        const ivkey = createRandomString(16)

        if (!fs.existsSync(`scripts/${id}/${scriptname}/${scriptname}.lua`) || !IsStringSafe(scriptname)) { return message.reply("Script does not exist.") }
        fs.writeFileSync(`keys/${randomkey}.json`, JSON.stringify({
            "Key": randomkey,
            "Owner": id.toString(),
            "Script": scriptname,
            "IV": ivkey,
            "Perm": perm || false,
            "Time": t
        }, null, 4))

        setInterval(() => {
            if (fs.existsSync(`keys/${randomkey}.json`)) {
                fs.rmSync(`keys/${randomkey}.json`)
            }
        }, t * 60 * 1000)

        message.reply(`Key for '${scriptname}' has been sent to your DMs.`)
        return message.author.send(`\`\`\`lua
-- ${scriptname}, ${t == "perm" && "perm" || `${t}m`} key
require(17890624224)("${randomkey}", "${ivkey}", owner and owner.Name or "${GetRobloxUser(id) || "username"}")
\`\`\``)
    }
}

export default AnonymousCommand