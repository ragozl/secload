import { Listener } from '@sapphire/framework';

export class ChatInputCommandDenied extends Listener {
    run(error, { interaction }) {
        const isSilent = Reflect.get(Object(error.context), 'silent');

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                content: isSilent ? '\u200b' : error.message
            });
        }

        return interaction.reply({
            content: isSilent ? '\u200b' : error.message,
            ephemeral: false
        });
    }
}