import { Listener } from '@sapphire/framework';

export class MessageCommandDenied extends Listener {
    run(error, { message }) {
        if (Reflect.get(Object(error.context), 'silent')) return;
        return message.channel.send(error.message);
    }
}