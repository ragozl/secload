import { Listener } from '@sapphire/framework';

// funny mario
export class UserEvent extends Listener {
    /**
     * @param {Listener.LoaderContext} context
     */
    constructor(context) {
        super(context, {
            // Any Listener options you want here
        });
    }

    async run(message) {
        if (message.author.bot || message.content.toString().startsWith(";")) return;
        if (message.content.toLowerCase().search("mario") != -1) {
            await message.react("1299634317181325312")
        }
    }
}