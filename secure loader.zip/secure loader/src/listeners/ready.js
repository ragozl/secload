import { Listener } from '@sapphire/framework';
import { debug } from "../library.js"
import { PresenceUpdateStatus, ActivityType } from 'discord.js'

class UserEvent extends Listener {
    /**
     * @param {Listener.LoaderContext} context
     */
    constructor(context) {
        super(context, {});
    }

    run(client) {
        const { username, id } = client.user;
        client.user.setPresence({
            activities: [
                {
                    name: 'loading rares',
                    type: ActivityType.Playing,
                    url: "https://secload.scriptlang.com"
                }
            ],
            status: PresenceUpdateStatus.Playing
        });
        debug.log(`[init]: logged in as ${username} (${id})`)
    }
}

export default UserEvent