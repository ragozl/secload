import crypto from "crypto"
import * as Sentry from "@sentry/node"
import { Listener, Events } from '@sapphire/framework';
import { EmbedBuilder, WebhookClient } from "discord.js";
import { debug } from "../library.js"

export class MessageCommandErrorListener extends Listener {
    /**
         * @param {Listener.LoaderContext} context
         */
    constructor(context) {
        super(context, {
            event: Events.MessageCommandError
        });
    }

    async run(error, { message }) {
        const sentry = Sentry.captureException(error)
        const id = crypto.randomBytes(12).toString("hex")

        const emb = new EmbedBuilder()
            .setAuthor({
                name: "SecLoad - Command Error"
            })
            .setDescription(`\`\`\`\n${error}\`\`\``)
            .addFields({ name: "Error ID", value: `${id}` }, { name: "Command", value: `${arguments[1].command.name}`, inline: true }, { name: `Sentry Report`, value: `https://sentry.io/${sentry}` })
            .setColor("Red")

        const wh = new WebhookClient({ url: "https://discord.com/api/webhooks/1298127978445803554/5QMMJp-s7enn_wuicx_DLaKx6RzjtXOMDxZOTfYX1Hjg-UoK7NvWLuj2JnrLe6U31k0Q" })

        wh.send({ embeds: [emb], content: `<@622319114530324491> An error has occured.` })

        debug.error(`Encountered the following while running: https://sentry.io/${sentry}. Command: ${arguments[1].command.name} (ERROR ID: ${id}) Error: ${error}`)
        message.reply({ content: `An error has occured while running this command. Report this error ID to a developer: **\`\`${id}\`\`**` })
    }
}